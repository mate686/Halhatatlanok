﻿namespace Halhatatlanok.ViewModels
{
    public class Feladat5Model
    {
        public string FoglalkozasNeve { get; set; }
       
        public int DB { get; set; }
    }
}
