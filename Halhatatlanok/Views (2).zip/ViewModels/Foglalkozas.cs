﻿namespace Halhatatlanok.ViewModels
{
    public class Foglalkozas
    {

       public string Nev { get; set; }
       public string FoglalkozasMeg { get; set; } 
        
    }
}
