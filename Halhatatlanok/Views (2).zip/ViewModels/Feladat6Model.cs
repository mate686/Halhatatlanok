﻿namespace Halhatatlanok.ViewModels
{
    
        public class Feladat6Model
        {

            public string Foglalkozas { get; set; }

            public string Nev { get; set; }

            public int Ev { get; set; }
        }
    
}
